import { Injectable } from '@angular/core';

import { Patient } from './model/patientdetails';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './model/user';
import { Login } from './model/login';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  baseUrl = "http://localhost:8888";
  // baseUrl = 'http://localhost:8888/getPatient';

  constructor(private http: HttpClient) { }

  addPatient(patient: Patient) {
    return this.http.post<Patient>(this.baseUrl + '/addPatient', patient);
  }

  getPatient(): Observable<Patient[]> {
    return this.http.get<Patient[]>(this.baseUrl + '/getPatient');
  }


  addUser(user: User) {
    return this.http.post<User>(this.baseUrl + '/addUser', user);
  }

  getUser(): Observable<User[]> {

    return this.http.get<User[]>(this.baseUrl + '/getUsers');
  }

  getUserByEmail(email): Observable<User> {
    return this.http.get<User>(this.baseUrl + '/getUserByEmail/' + email);
  }



  verifyUser(userlogin): Observable<User> {
    return this.http.post<User>(this.baseUrl + '/verifyUser', userlogin);
  }


  getAdmin(): Observable<Login[]> {

    return this.http.get<Login[]>(this.baseUrl + '/getAdmin');
  }


  getBloodRequest(): Observable<Patient[]> {

    return this.http.get<Patient[]>(this.baseUrl + '/getBloodRequest');
  }

  sendRequestToUser(patient: Patient) {
    return this.http.post<Patient>(this.baseUrl + '/sendRequestToUser', patient);
  }

  matchUser(bloodgroup: string, location: string) {

    return this.http.get<User[]>(this.baseUrl + '/matchbloodgroup/' + bloodgroup + '/' + location)


  }
  selectUser(id: number) {
    return this.http.get<User>(this.baseUrl + '/selectuser/' + id);
  }


  deletePatients(id: number) {
    return this.http.delete<Patient[]>(this.baseUrl + '/deletePatients/' + id);
  }


  deleteUser(id: number) {
    return this.http.delete<User[]>(this.baseUrl + '/deleteUser/' + id);
  }


  // searchEmp(id: number) {
  //   var result = this.employeeArr.find(x => x.employeeId == id);
  //   if (result == null)
  //     return null; //if not found
  //   else
  //     return result; //if found then store it
  // }


  // searchPatient(id:number)
  // {
  //   return this.http.<Patient[]>(this.baseUrl + '/searchPatients/' + id);
  // }

  // getPatientById(id: number): Observable<Patient[]> {
  //   return this.http.get<Patient[]>(this.baseUrl + '/getPatientById/' );
  // }


  updatePatient(id: number, patient: Patient): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updatePatient/${id}`, patient);
  }

  getPatientById(paramIndex: number) {
    return this.http.get(`${this.baseUrl}/getPatientById/${paramIndex}`);
  }

  searchPatientById(id: number) {
    return this.http.get<Patient>(`${this.baseUrl}/getPatientById/${id}`);
  }




  
  getUsertById(paramIndex: number) {
    return this.http.get(`${this.baseUrl}/getUserById/${paramIndex}`);
  }

  searchUserById(id: number) {
    return this.http.get<User>(`${this.baseUrl}/getUserById/${id}`);
  }
}
