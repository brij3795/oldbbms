package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Patient;
import com.cg.repo.PatientRepo;

@Service
public class PatientServiceImpl implements PatientService {

	@Autowired
	PatientRepo patientRepo;

	@Override
	public Patient addPatient(Patient p) {
		return patientRepo.save(p);
	}

	@Override
	public List<Patient> getPatientList() {
		return (List<Patient>) patientRepo.findAll();
	}

	@Override
	public String deletePatients(int id) {
		Patient a1 = patientRepo.findById(id).get();
		patientRepo.delete(a1);
		return "Deleted Successfully";
	}

	@Override
	public Patient getPatientById(int id) {
		Patient p1 = patientRepo.findById(id).get();
		return p1;
	}

	@Override
	public Patient updatePatient(int id, Patient p) {
		p.setId(id);
		return patientRepo.save(p);
	}

}
