package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Admin;
import com.cg.entity.Patient;
import com.cg.entity.User;
import com.cg.service.AdminService;
import com.cg.service.PatientService;
import com.cg.service.UserService;

@CrossOrigin("http://localhost:4200")
@RestController
public class BloodBankManagementSystemContoller {

	@Autowired
	private AdminService adminservice;

	@Autowired
	private PatientService patientservice;

	@Autowired
	private UserService userservice;

	@PostMapping(path = "/addPatient", consumes = "application/json", produces = "application/json")
	public Patient addPatient(@RequestBody Patient p) {
		return patientservice.addPatient(p);
	}

	@GetMapping(path = "/getPatient", produces = "application/json")
	public List<Patient> getPatientList() {
		return (List<Patient>) patientservice.getPatientList();
	}

	@PostMapping(path = "/addAdmin", consumes = "application/json", produces = "application/json")
	public Admin addAdmin(@RequestBody Admin a) {
		return adminservice.addAdmin(a);
	}

	@GetMapping(path = "/getAdmin", produces = "application/json")
	public List<Admin> getAdminList() {
		return (List<Admin>) adminservice.getAdminList();
	}

	@PostMapping(path = "/addUser", consumes = "application/json", produces = "application/json")
	public User addUser(@RequestBody User u) {

		return userservice.addUser(u);
	}

	@GetMapping(path = "/getUsers", produces = "application/json")
	public List<User> getUser() {
		return (List<User>) userservice.getUser();

	}
	
	@GetMapping(path = "/getUserByEmail/{email}", produces = "application/json")
	public User getUserByEmail(@PathVariable("email") String email) {
		return userservice.getUserByEmail(email);

	}

	@PutMapping(path = "/updatePatient/{id}", consumes = "application/json")
	public Patient updatePatient(@PathVariable("id") int id, @RequestBody Patient e) {
		return patientservice.updatePatient(id, e);

	}

	@GetMapping(path = "/getPatientById/{id}", produces = "application/json")
	public Patient getPatientById(@PathVariable("id") int id) {
		return patientservice.getPatientById(id);
	}
	
	
	@GetMapping(path = "/getUserById/{id}", produces = "application/json")
	public User getUserById(@PathVariable("id") int id) {
		return userservice.getUserById(id);
	}

	@GetMapping(path = "/matchbloodgroup/{bloodgroup}/{location}", produces = "application/json")
	public List<User> getByBloodGroupLocation(@PathVariable("bloodgroup") String bloodgroup,
			@PathVariable("location") String location) {
		return userservice.matchUser(bloodgroup, location);
	}

	@GetMapping(path = "/selectuser/{userid}", produces = "application/json")
	public User selectUser(@PathVariable int userid) {
		return userservice.selectUser(userid);
	}

	@DeleteMapping(path = "/deletePatients/{id}")
	public String deletePatients(@PathVariable("id") int id) {
		return patientservice.deletePatients(id);
	}
	
	@DeleteMapping(path = "/deleteUser/{id}")
	public String deleteUser(@PathVariable("id") int id) {
		return userservice.deleteUser(id);
	}
	
	@PostMapping(path = "/verifyUser", consumes = "application/json", produces = "application/json")
	public User verifyUser(@RequestBody User user) {
		return userservice.verifyUser(user);
	}

}
